export default {
  "trailingSlash": true,
  "pathPrefix": "",
  "titleTemplate": "%s - blog",
  "siteUrl": "",
  "version": "0.7.23",
  "catchLinks": true
}
const c1 = () => import(/* webpackChunkName: "page--src-templates-source-detail-vue" */ "C:\\project\\code\\homework\\zwq-task\\zwq-task\\task-03-04\\code\\gridsome-blog2\\src\\templates\\source\\detail.vue")
const c2 = () => import(/* webpackChunkName: "page--src-templates-blog-edit-vue" */ "C:\\project\\code\\homework\\zwq-task\\zwq-task\\task-03-04\\code\\gridsome-blog2\\src\\templates\\blog\\edit.vue")
const c3 = () => import(/* webpackChunkName: "page--src-templates-blog-detail-vue" */ "C:\\project\\code\\homework\\zwq-task\\zwq-task\\task-03-04\\code\\gridsome-blog2\\src\\templates\\blog\\detail.vue")
const c4 = () => import(/* webpackChunkName: "page--src-templates-social-detail-vue" */ "C:\\project\\code\\homework\\zwq-task\\zwq-task\\task-03-04\\code\\gridsome-blog2\\src\\templates\\social\\detail.vue")
const c5 = () => import(/* webpackChunkName: "page--src-pages-blog-add-vue" */ "C:\\project\\code\\homework\\zwq-task\\zwq-task\\task-03-04\\code\\gridsome-blog2\\src\\pages\\blog\\add.vue")
const c6 = () => import(/* webpackChunkName: "page--src-pages-social-index-vue" */ "C:\\project\\code\\homework\\zwq-task\\zwq-task\\task-03-04\\code\\gridsome-blog2\\src\\pages\\social\\index.vue")
const c7 = () => import(/* webpackChunkName: "page--src-pages-source-index-vue" */ "C:\\project\\code\\homework\\zwq-task\\zwq-task\\task-03-04\\code\\gridsome-blog2\\src\\pages\\source\\index.vue")
const c8 = () => import(/* webpackChunkName: "page--src-pages-blog-index-vue" */ "C:\\project\\code\\homework\\zwq-task\\zwq-task\\task-03-04\\code\\gridsome-blog2\\src\\pages\\blog\\index.vue")
const c9 = () => import(/* webpackChunkName: "page--src-pages-register-index-vue" */ "C:\\project\\code\\homework\\zwq-task\\zwq-task\\task-03-04\\code\\gridsome-blog2\\src\\pages\\register\\index.vue")
const c10 = () => import(/* webpackChunkName: "page--src-pages-login-index-vue" */ "C:\\project\\code\\homework\\zwq-task\\zwq-task\\task-03-04\\code\\gridsome-blog2\\src\\pages\\login\\index.vue")
const c11 = () => import(/* webpackChunkName: "page--src-pages-about-vue" */ "C:\\project\\code\\homework\\zwq-task\\zwq-task\\task-03-04\\code\\gridsome-blog2\\src\\pages\\About.vue")
const c12 = () => import(/* webpackChunkName: "page--node-modules-gridsome-app-pages-404-vue" */ "C:\\project\\code\\homework\\zwq-task\\zwq-task\\task-03-04\\code\\gridsome-blog2\\node_modules\\gridsome\\app\\pages\\404.vue")
const c13 = () => import(/* webpackChunkName: "page--src-pages-index-vue" */ "C:\\project\\code\\homework\\zwq-task\\zwq-task\\task-03-04\\code\\gridsome-blog2\\src\\pages\\Index.vue")

export default [
  {
    path: "/source/detail/:id/",
    component: c1
  },
  {
    path: "/blog/edit/:id/",
    component: c2
  },
  {
    path: "/blog/detail/:id/",
    component: c3
  },
  {
    name: "socialDetail",
    path: "/social/detail/",
    component: c4
  },
  {
    path: "/blog/add/",
    component: c5
  },
  {
    path: "/social/:page(\\d+)?/",
    component: c6
  },
  {
    path: "/source/:page(\\d+)?/",
    component: c7
  },
  {
    path: "/blog/:page(\\d+)?/",
    component: c8
  },
  {
    path: "/register/",
    component: c9
  },
  {
    path: "/login/",
    component: c10
  },
  {
    path: "/about/",
    component: c11
  },
  {
    name: "404",
    path: "/404/",
    component: c12
  },
  {
    name: "home",
    path: "/",
    component: c13
  },
  {
    name: "*",
    path: "*",
    component: c12
  }
]
